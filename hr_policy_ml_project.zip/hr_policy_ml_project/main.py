"""FastAPI website + simple JSON prediction endpoints."""
from pathlib import Path
import json
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
app = FastAPI(title='HR Policy Explorer')
app.mount('/static', StaticFiles(directory=ROOT / 'static'), name='static')
RESULTS = json.loads((ROOT / 'models' / 'results.json').read_text())
MODELS = {name: joblib.load(ROOT / 'models' / f'{name}.joblib') for name in RESULTS}

class Employee(BaseModel):
    gender: str = 'Female'
    occupation_type: str = 'Teacher'
    avg_work_hours_per_day: float = Field(9, ge=0, le=24)
    avg_rest_hours_per_day: float = Field(6, ge=0, le=24)
    avg_sleep_hours_per_day: float = Field(7, ge=0, le=24)
    avg_exercise_hours_per_day: float = Field(1, ge=0, le=24)

def schedule_text(data):
    w = data['avg_work_hours_per_day']
    word = 'short' if w < 8 else 'regular' if w < 10 else 'extended'
    return f"{data['occupation_type']} {data['gender']} {word} schedule"

@app.get('/')
def home():
    return FileResponse(ROOT / 'static' / 'index.html')

@app.get('/api/models')
def models():
    return RESULTS

@app.post('/api/predict/{model_name}')
def predict(model_name: str, employee: Employee):
    if model_name not in MODELS:
        raise HTTPException(status_code=404, detail='Unknown model')
    data = employee.model_dump()
    features = RESULTS[model_name]['features']
    X = [schedule_text(data)] if model_name == 'tfidf' else pd.DataFrame([data])[features]
    value = MODELS[model_name].predict(X)[0]
    if RESULTS[model_name]['type'] == 'Regression':
        answer = f'Estimated historical age at death: {float(value):.1f} years (not a personal forecast)'
    elif model_name == 'svm':
        answer = ['Short workday','Regular workday','Extended workday'][int(value)]
    else:
        labels = {
            'logistic_regression': ('Under 9.5 work hours', 'Long workday: consider workload review'),
            'random_forest': ('No combined workload/rest flag', 'High workload and limited rest: review schedule'),
            'decision_tree': ('Sleep at least 7 hours', 'Short sleep: consider wellbeing resources'),
            'naive_bayes': ('Exercise at least 1 hour', 'Low exercise: consider activity-friendly policies'),
            'tfidf': ('Not an extended workday', 'Extended workday from schedule text'),
        }
        answer = labels[model_name][int(value)]
    return {'model':model_name,'result':answer,'raw_prediction':float(value),'metrics':RESULTS[model_name]['metrics']}
