const modelSelect = document.getElementById('model');
let modelInfo = {};
async function start() {
  modelInfo = await (await fetch('/api/models')).json();
  for (const [key, item] of Object.entries(modelInfo)) {
    const option = document.createElement('option');
    option.value = key; option.textContent = key.replaceAll('_', ' ').toUpperCase();
    modelSelect.appendChild(option);
  }
  modelSelect.addEventListener('change', showTask);
  showTask();
  const jobs = ['Teacher','Office Worker','Freelancer','Engineer','Doctor','Nurse','Manager','Student','Retail Worker','Factory Worker','Driver','Farmer','Business Owner','Other'];
  document.getElementById('occupation').innerHTML = jobs.map(j => `<option>${j}</option>`).join('');
  const rows = Object.entries(modelInfo).map(([name,item]) => {
    const m=item.metrics;
    const score = item.type==='Regression' ? `MAE: ${m.MAE}, R²: ${m.R2} (baseline MAE: ${m.baseline_MAE})` : `Accuracy: ${(m.accuracy*100).toFixed(1)}%, Precision: ${(m.precision*100).toFixed(1)}%, Recall: ${(m.recall*100).toFixed(1)}%, F1: ${(m.f1*100).toFixed(1)}% (baseline accuracy: ${(m.baseline_accuracy*100).toFixed(1)}%)`;
    return `<tr><td>${name.replaceAll('_',' ')}</td><td>${item.task}</td><td>${score}</td></tr>`;
  }).join('');
  document.getElementById('scores').innerHTML = `<table><thead><tr><th>Model</th><th>Business question</th><th>Test result</th></tr></thead><tbody>${rows}</tbody></table>`;
}
function showTask() { document.getElementById('task').textContent = modelInfo[modelSelect.value].task; document.getElementById('output').textContent=''; }
document.getElementById('form').addEventListener('submit', async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.target));
  for (const key of Object.keys(data)) if (key.startsWith('avg_')) data[key] = Number(data[key]);
  const output = document.getElementById('output'); output.textContent='Predicting...';
  try {
    const response = await fetch('/api/predict/' + modelSelect.value, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const result = await response.json();
    if (!response.ok) throw new Error(JSON.stringify(result.detail));
    output.textContent = result.result;
  } catch(error) {output.textContent = 'Error: ' + error.message;}
});
start().catch(e => document.getElementById('output').textContent = e.message);
