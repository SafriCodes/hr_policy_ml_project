"""Train 10 beginner-friendly ML examples on the supplied data."""
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, PolynomialFeatures
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, Lasso, LogisticRegression, Ridge
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_absolute_error, r2_score

ROOT = Path(__file__).parent
DATA = pd.read_csv(ROOT / 'quality_of_life.csv')
OUT = ROOT / 'models'
OUT.mkdir(exist_ok=True)
# Every task uses the SAME 80/20 split. The ID is never a predictor.
train_idx, test_idx = train_test_split(np.arange(len(DATA)), test_size=.2, random_state=42)
NUM = ['avg_work_hours_per_day','avg_rest_hours_per_day','avg_sleep_hours_per_day','avg_exercise_hours_per_day']
CAT = ['gender','occupation_type']

def prep(columns):
    numeric = [c for c in columns if c in NUM]
    categorical = [c for c in columns if c in CAT]
    return ColumnTransformer([
        ('numbers', make_pipeline(SimpleImputer(strategy='median'), StandardScaler()), numeric),
        ('categories', make_pipeline(SimpleImputer(strategy='most_frequent'), OneHotEncoder(handle_unknown='ignore', sparse_output=False)), categorical),
    ])

def sentence(row):
    # TF-IDF receives textual descriptions, not the class label itself.
    w = row['avg_work_hours_per_day']
    word = 'short' if w < 8 else 'regular' if w < 10 else 'extended'
    return f"{row['occupation_type']} {row['gender']} {word} schedule"

# Rule-defined policy categories, not independently measured HR outcomes.
def label(task, df):
    w = df['avg_work_hours_per_day']
    s = df['avg_sleep_hours_per_day']
    r = df['avg_rest_hours_per_day']
    e = df['avg_exercise_hours_per_day']
    if task == 'logistic_regression': return (w >= 9.5).astype(int)
    if task == 'random_forest': return ((w >= 9) & (r < 6)).astype(int)
    if task == 'decision_tree': return (s < 7).astype(int)
    if task == 'naive_bayes': return (e < 1).astype(int)
    if task == 'svm': return pd.Series(np.select([w >= 10, w >= 8], [2, 1], default=0), index=df.index)
    if task == 'tfidf': return (w >= 10).astype(int)
    raise ValueError(task)

# Regression models estimate age_at_death, a historical association ONLY.
# The 4 regressors use different feature sets/methods, but the same outcome.
REG = {
    'linear_regression': (['avg_work_hours_per_day'], make_pipeline(prep(['avg_work_hours_per_day']), LinearRegression())),
    'multiple_regression': (['avg_work_hours_per_day','avg_sleep_hours_per_day','avg_exercise_hours_per_day'] + CAT, make_pipeline(prep(['avg_work_hours_per_day','avg_sleep_hours_per_day','avg_exercise_hours_per_day'] + CAT), LinearRegression())),
    'polynomial_regression': (NUM, make_pipeline(prep(NUM), PolynomialFeatures(degree=2, include_bias=False), Ridge(alpha=10))),
    'lasso_regression': (NUM + CAT, make_pipeline(prep(NUM + CAT), Lasso(alpha=.1, max_iter=5000))),
}
CLS = {
    'logistic_regression': (['avg_work_hours_per_day'], make_pipeline(prep(['avg_work_hours_per_day']), LogisticRegression(max_iter=1000, C=10))),
    'random_forest': (['avg_work_hours_per_day','avg_rest_hours_per_day'], make_pipeline(prep(['avg_work_hours_per_day','avg_rest_hours_per_day']), RandomForestClassifier(n_estimators=100, max_depth=9, min_samples_leaf=2, random_state=42))),
    'decision_tree': (['avg_sleep_hours_per_day'], make_pipeline(prep(['avg_sleep_hours_per_day']), DecisionTreeClassifier(max_depth=2, random_state=42))),
    'naive_bayes': (['avg_exercise_hours_per_day'], make_pipeline(prep(['avg_exercise_hours_per_day']), GaussianNB())),
    'svm': (['avg_work_hours_per_day'], make_pipeline(prep(['avg_work_hours_per_day']), SVC(kernel='rbf', C=10))),
    'tfidf': (['text'], make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), MultinomialNB(alpha=.1))),
}
TASKS = {
 'linear_regression': ('Age-at-death association: work hours', 'Regression'),
 'multiple_regression': ('Age-at-death association: full lifestyle', 'Regression'),
 'polynomial_regression': ('Age-at-death association: nonlinear lifestyle', 'Regression'),
 'lasso_regression': ('Age-at-death association: simplified factors', 'Regression'),
 'logistic_regression': ('Long workday flag (9.5+ hours)', 'Classification'),
 'random_forest': ('High workload + limited rest flag', 'Classification'),
 'decision_tree': ('Short sleep flag (under 7 hours)', 'Classification'),
 'naive_bayes': ('Low exercise flag (under 1 hour)', 'Classification'),
 'svm': ('Workday category: short / regular / extended', 'Classification'),
 'tfidf': ('Schedule-text classification: extended workday', 'Classification'),
}
results = {}
for name, (cols, model) in {**REG, **CLS}.items():
    if name == 'tfidf':
        X = DATA.apply(sentence, axis=1)
    else:
        X = DATA[cols]
    y = DATA['age_at_death'] if name in REG else label(name, DATA)
    Xtr, Xte = X.iloc[train_idx], X.iloc[test_idx]
    ytr, yte = y.iloc[train_idx], y.iloc[test_idx]
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    if name in REG:
        baseline = np.full(len(yte), ytr.mean())
        metrics = {'MAE':round(float(mean_absolute_error(yte,pred)),3),'R2':round(float(r2_score(yte,pred)),3),
                   'baseline_MAE':round(float(mean_absolute_error(yte,baseline)),3),'baseline_R2':round(float(r2_score(yte,baseline)),3)}
    else:
        common = ytr.mode().iloc[0]
        baseline = np.full(len(yte),common)
        metrics = {key:round(float(fn(yte,pred)),3) for key,fn in {
            'accuracy':accuracy_score,
            'precision':lambda a,b: precision_score(a,b,average='weighted',zero_division=0),
            'recall':lambda a,b: recall_score(a,b,average='weighted',zero_division=0),
            'f1':lambda a,b: f1_score(a,b,average='weighted',zero_division=0),
        }.items()}
        metrics['baseline_accuracy'] = round(float(accuracy_score(yte,baseline)),3)
        metrics['baseline_precision'] = round(float(precision_score(yte,baseline,average='weighted',zero_division=0)),3)
    joblib.dump(model, OUT / f'{name}.joblib')
    results[name] = {'task':TASKS[name][0], 'type':TASKS[name][1], 'metrics':metrics, 'features':cols}
    print(name,metrics,flush=True)
(OUT / 'results.json').write_text(json.dumps(results,indent=2))
print('Models and test results saved.')
